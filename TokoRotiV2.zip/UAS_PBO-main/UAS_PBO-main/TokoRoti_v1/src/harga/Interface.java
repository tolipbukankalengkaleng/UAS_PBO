/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package harga;

/**
 *
 * @author Lenovo
 */
public interface Interface {
    public double topping();
    public double filling();
    public double modal();
    public double hargaVarian();
    public void harga();
}
