/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package harga;

/**
 *
 * @author Lenovo
 */
public class BeratKemasan extends Harga {
    public int beratTepung = 1000;
    public int beratGulaPasir = 1000;
    public int beratButter = 500;
    public int beratRagi = 11;
    public int beratSusuBubuk = 1000;
    public int beratSusuCair = 1000;
    public int beratTelur = 1000;
    public int beratEsBatu = 1000;
    public int beratKeju = 250;
    public int beratCoklat = 500;
    public int beratKrim = 500;
    public int beratSelai = 500;
    public int beratSosis = 1000;
    public int beratBeef = 1000;
    public int beratBawang = 500;
}