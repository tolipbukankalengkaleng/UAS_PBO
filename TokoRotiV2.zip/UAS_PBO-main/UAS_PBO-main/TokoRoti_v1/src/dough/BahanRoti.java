/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dough;

/**
 *
 * @author Lenovo
 */
public interface BahanRoti {
    int tepungTerigu();
    int gulaPasir();
    int butter();
    int ragi();
    int susuBubuk();
    int susuCair();
    int telur();
    int esBatu();
    public int hitungKomposisi();
}
