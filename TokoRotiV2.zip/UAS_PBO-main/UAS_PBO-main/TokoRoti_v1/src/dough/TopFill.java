/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dough;

/**
 *
 * @author Lenovo
 */
public interface TopFill {
    public int keju();
    public int coklat();
    public int krim();
    public int selai();
    public int sosis();
    public int beef();
    public int bawang();
}
