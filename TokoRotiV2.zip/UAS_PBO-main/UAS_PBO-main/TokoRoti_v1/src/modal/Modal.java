/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modal;

/**
 *
 * @author Lenovo
 */
public interface Modal {
    public int beratDough();
    public double rotiPerAdonan();
    public double hitungTerigu();
    public double hitungGula();
    public double hitungButter();
    public double hitungRagi();
    public double hitungSusuBubuk();
    public double hitungSusuCair();
    public double hitungTelur();
    public double hitungEs();
    public double hitungModal();
}
